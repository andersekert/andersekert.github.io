#!/bin/bash

TITLE="Create Folders for Import and Backup"
TODAY=$(date +%Y%m%d)
CARDDATE=$(date +%Y%m%d)
HTML_FILE="$HOME/Desktop/fotograf_status.html"

# ── Load email config ─────────────────────────────────────────────────────────
CONFIG="$HOME/.import_backup_config"
if [ ! -f "$CONFIG" ]; then
    cat > "$CONFIG" << 'CONFIGEOF'
# Import & Backup — email notification config
# Fill in your details and save this file.
# App password: myaccount.google.com/security → App passwords

GMAIL_FROM="yourname@gmail.com"
GMAIL_APP_PASSWORD="xxxx xxxx xxxx xxxx"
NOTIFY_TO="yourname@gmail.com"
CONFIGEOF
    osascript -e "display dialog \"A config file was created at:\n$CONFIG\n\nOpen it, fill in your Gmail address and app password to enable phone notifications, then run the app again.\" with title \"$TITLE\" buttons {\"Open config file\", \"Skip\"} default button \"Open config file\""
    RESP=$?
    [ $RESP -eq 0 ] && open -t "$CONFIG"
fi
source "$CONFIG" 2>/dev/null

write_html() {
    local json="$1"
    cat > "$HTML_FILE" << HTMLEOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="2">
<title>Import &amp; Backup</title>
<style>
:root { --ink: #111111; --ink-soft: #5e5e5e; --line: #e4e4e4; --paper: #ffffff; --sunk: #f4f4f4; --ok: #2f6b3a; --danger: #b00020; --danger-bg: #fde8e8; --ok-bg: #e4f2d4; color-scheme: light; }
@media (prefers-color-scheme: dark) { :root { --ink: #f2f2f2; --ink-soft: #a6a6a6; --line: #333333; --paper: #111111; --sunk: #1c1c1c; --ok: #7fd28f; --danger: #ff8a80; --danger-bg: #3a1a18; --ok-bg: #1f3315; color-scheme: dark; } }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: "Hanken Grotesk", -apple-system, BlinkMacSystemFont, "Helvetica Neue", sans-serif; font-variant-numeric: tabular-nums; background: var(--paper); color: var(--ink); max-width: 44rem; margin: 0 auto; padding: 24px 16px 48px; }
h1 { font-size: 36px; font-weight: 700; letter-spacing: -0.02em; line-height: 1.08; margin-bottom: 12px; }
.sub { font-size: 16px; color: var(--ink-soft); }
.project { font-size: 16px; font-weight: 500; margin-bottom: 24px; }
.card { border-top: 1px solid var(--line); padding: 20px 0; }
.card:first-of-type { border-top-color: var(--ink); }
.card-header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.cam-label { font-size: 18px; font-weight: 700; flex: 1; }
.badge { font-size: 14px; font-weight: 500; padding: 3px 10px; }
.badge-waiting   { color: var(--ink-soft); }
.badge-copying   { background: var(--ink); color: var(--paper); }
.badge-verifying { background: var(--sunk); color: var(--ink); }
.badge-ok        { background: var(--ok-bg); color: var(--ok); }
.badge-existing  { color: var(--ink-soft); }
.badge-warning   { background: var(--danger-bg); color: var(--danger); }
.track { height: 4px; background: var(--line); overflow: hidden; margin-bottom: 12px; }
.bar { height: 100%; }
.stats { display: flex; gap: 24px; }
.stat { font-size: 14px; color: var(--ink-soft); }
.stat span { display: block; font-size: 16px; font-weight: 500; color: var(--ink); margin-top: 2px; }
.locs { display: flex; gap: 16px; margin-top: 10px; }
.loc { font-size: 14px; color: var(--ink-soft); display: flex; align-items: center; gap: 6px; }
.dot { width: 7px; height: 7px; display: inline-block; }
.show-files-btn { margin-top: 12px; min-height: 44px; font: inherit; font-size: 14px; font-weight: 500; background: var(--paper); border: 1px solid var(--ink); padding: 0 14px; cursor: pointer; color: var(--ink); }
.show-files-btn:hover { color: var(--ink-soft); border-color: var(--ink-soft); }
.finder-btn { margin-top: 12px; margin-left: 8px; min-height: 44px; font-size: 14px; font-weight: 500; border: 1px solid var(--ink); padding: 0 14px; color: var(--ink); text-decoration: none; display: inline-flex; align-items: center; }
.finder-btn:hover { color: var(--ink-soft); border-color: var(--ink-soft); }
.exif-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 16px; margin-top: 12px; padding: 12px 0; border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); }
.exif-label { color: var(--ink-soft); display: block; margin-bottom: 1px; font-size: 14px; }
.exif-value { font-weight: 500; font-size: 14px; }
.file-panel { display: none; margin-top: 10px; border-top: 1px solid var(--line); max-height: 220px; overflow-y: auto; }
.file-panel.open { display: block; }
.file-row { display: flex; align-items: center; gap: 10px; padding: 7px 0; border-bottom: 1px solid var(--line); font-size: 14px; }
.file-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.file-size { color: var(--ink-soft); flex-shrink: 0; }
.summary { border-top: 1px solid var(--ink); padding: 20px 0; display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.sum { font-size: 14px; color: var(--ink-soft); }
.sum span { display: block; font-size: 24px; font-weight: 700; color: var(--ink); }
</style>
</head>
<body>
<div id="app"></div>
<script>
var d = $json;
function fmt(b) {
    if (!b||b<=0) return "—";
    var gb=b/1073741824; if(gb>=1) return gb.toFixed(1)+" GB";
    return Math.round(b/1048576)+" MB";
}
function pct(a,b){ return b>0?Math.round(a/b*100):0; }
var html="<h1>Import &amp; Backup</h1>";
html+="<div class='sub'>"+d.cameras+" cameras &middot; "+d.cards_per_cam+" cards each</div>";
html+="<div class='project'>"+d.project+"</div>";
d.cards.forEach(function(c){
    var p=pct(c.copied_files,c.src_files||1);
    var barColor="var(--line)",badgeClass="badge-waiting",badgeText="Waiting";
    if(c.status==="existing")  {barColor="var(--line)";badgeClass="badge-existing"; badgeText="Already copied"; p=100;}
    if(c.status==="copying")   {barColor="var(--ink)";badgeClass="badge-copying";  badgeText="Copying&hellip;";}
    if(c.status==="verifying") {barColor="var(--ink-soft)";badgeClass="badge-verifying";badgeText="Verifying&hellip;";p=100;}
    if(c.status==="reading EXIF"){barColor="var(--ink-soft)";badgeClass="badge-verifying";badgeText="Reading EXIF&hellip;";p=100;}
    if(c.status==="ok")        {barColor="var(--ok)";badgeClass="badge-ok";       badgeText="Verified";p=100;}
    if(c.status==="warning")   {barColor="var(--danger)";badgeClass="badge-warning";  badgeText="Warning";p=100;}
    var filesStr=c.src_files?(c.status==="ok"||c.status==="warning"?c.src_files:c.copied_files+"/"+c.src_files):"—";
    var csStr=c.checksum==="ok"?"<span style='color:var(--ok)'>OK</span>":c.checksum==="failed"?"<span style='color:var(--danger)'>Failed</span>":c.checksum==="skipped"?"Skipped":"—";
    var dotColor=c.status!=="waiting"&&c.status!=="existing"?"var(--ok)":"var(--line)";
    html+="<div class='card' style='"+(c.status==="existing"?"opacity:0.45":"")+"'>";
    html+="<div class='card-header'><div class='cam-label'>Cam-"+c.cam+" / Card-"+c.card+"</div><div class='badge "+badgeClass+"'>"+badgeText+"</div></div>";
    html+="<div class='track'><div class='bar' style='width:"+p+"%;background:"+barColor+"'></div></div>";
    html+="<div class='stats'><div class='stat'>Files<span>"+filesStr+"</span></div><div class='stat'>Size<span>"+fmt(c.src_bytes)+"</span></div><div class='stat'>Checksum<span>"+csStr+"</span></div></div>";
    html+="<div class='locs'><div class='loc'><span class='dot' style='background:"+dotColor+"'></span>Import</div>";
    if(c.backup)html+="<div class='loc'><span class='dot' style='background:"+dotColor+"'></span>Backup</div>";
    html+="</div>";
    if(c.exif && (c.exif.camera||c.exif.dates||c.exif.iso)){
        var e=c.exif;
        html+="<div class='exif-grid'>";
        if(e.camera) html+="<div class='exif-item'><span class='exif-label'>Camera</span><span class='exif-value'>"+e.camera+"</span></div>";
        if(e.lens)   html+="<div class='exif-item'><span class='exif-label'>Lens</span><span class='exif-value'>"+e.lens+"</span></div>";
        if(e.iso)    html+="<div class='exif-item'><span class='exif-label'>ISO (most common)</span><span class='exif-value'>"+e.iso+"</span></div>";
        if(e.shutter)html+="<div class='exif-item'><span class='exif-label'>Shutter</span><span class='exif-value'>"+e.shutter+"</span></div>";
        if(e.aperture)html+="<div class='exif-item'><span class='exif-label'>Aperture</span><span class='exif-value'>f/"+e.aperture+"</span></div>";
        if(e.dates)  html+="<div class='exif-item'><span class='exif-label'>Date</span><span class='exif-value'>"+e.dates+"</span></div>";
        if(e.gps)    html+="<div class='exif-item' style='grid-column:span 2'><span class='exif-label'>GPS</span><span class='exif-value'>"+e.gps+"</span></div>";
        html+="</div>";
    }
    if(c.files && c.files.length>0){
        var panelId="panel_"+c.cam+"_"+c.card;
        html+="<button class='show-files-btn' onclick=\"var p=document.getElementById('"+panelId+"');var open=p.classList.toggle('open');this.textContent=open?'Hide files ("+c.files.length+")':'Show files ("+c.files.length+")';\">Show files ("+c.files.length+")</button>";
        if(c.dest){html+="<a class='finder-btn' href='file://"+c.dest+"'>Show in Finder</a>";}
        html+="<div class='file-panel' id='"+panelId+"'>";
        c.files.forEach(function(f){
            var sz=f.size>0?(f.size>1048576?(f.size/1048576).toFixed(1)+" MB":Math.round(f.size/1024)+" KB"):"";
            html+="<div class='file-row'><span class='file-name'>"+f.name+"</span><span class='file-size'>"+sz+"</span></div>";
        });
        html+="</div>";
    }
    html+="</div>";
});
var totalFiles=d.cards.reduce(function(s,c){return s+(c.copied_files||0);},0);
var totalBytes=d.cards.reduce(function(s,c){return s+(c.copied_bytes||0);},0);
var verified=d.cards.filter(function(c){return c.status==="ok";}).length;
html+="<div class='summary'>";
html+="<div class='sum'><span>"+totalFiles+"</span>files copied</div>";
html+="<div class='sum'><span>"+fmt(totalBytes)+"</span>copied</div>";
html+="<div class='sum'><span>"+(d.eta||"—")+"</span>remaining</div>";
html+="<div class='sum'><span style='color:var(--ok)'>"+verified+"</span>verified</div>";
html+="</div>";
document.getElementById("app").innerHTML=html;
</script>
</body>
</html>
HTMLEOF
}

card_set() { echo "$4" > "/tmp/fotograf_${1}_${2}_${3}"; }
card_get() { cat "/tmp/fotograf_${1}_${2}_${3}" 2>/dev/null || echo ""; }

build_json() {
    local project="$1" cameras="$2" cards_per="$3" eta="$4" has_backup="$5"
    local cards_json="[" first=true
    for ((kk=1; kk<=cards_per; kk++)); do
        for ((cc=1; cc<=cameras; cc++)); do
            $first || cards_json+=","
            local status=$(card_get $cc $kk status); [ -z "$status" ] && status="waiting"
            local cs=$(card_get $cc $kk cs);         [ -z "$cs" ]     && cs="—"
            local sf=$(card_get $cc $kk sf);         [ -z "$sf" ]     && sf="0"
            local cf=$(card_get $cc $kk cf);         [ -z "$cf" ]     && cf="0"
            local sb=$(card_get $cc $kk sb);         [ -z "$sb" ]     && sb="0"
            local cb=$(card_get $cc $kk cb);         [ -z "$cb" ]     && cb="0"
            local files=$(card_get $cc $kk files);   [ -z "$files" ]  && files="[]"
            local dest=$(card_get $cc $kk dest);     dest=$(echo "$dest" | sed 's/"/\\"/g')
            local exif=$(card_get $cc $kk exif);     [ -z "$exif" ] && exif="{}"
            cards_json+="{\"cam\":$cc,\"card\":$kk,\"status\":\"$status\",\"backup\":$has_backup,\"checksum\":\"$cs\",\"src_files\":$sf,\"copied_files\":$cf,\"src_bytes\":$sb,\"copied_bytes\":$cb,\"files\":$files,\"dest\":\"$dest\",\"exif\":$exif}"
            first=false
        done
    done
    cards_json+="]"
    echo "{\"project\":\"$project\",\"cameras\":$cameras,\"cards_per_cam\":$cards_per,\"eta\":\"$eta\",\"cards\":$cards_json}"
}

copy_card() {
    local c=$1 k=$2 source=$3 dest1=$4 dest2=$5
    local src_files=$(find "$source" -type f | wc -l | tr -d ' ')
    local src_bytes=$(du -sk "$source" | awk '{print $1*1024}')
    card_set $c $k status "copying"
    card_set $c $k sf "$src_files"
    card_set $c $k sb "$src_bytes"
    card_set $c $k cf "0"
    write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
    local copied=0
    while IFS= read -r -d '' src_file; do
        local rel="${src_file#$source/}"
        local d1="$dest1/$rel"
        mkdir -p "$(dirname "$d1")"
        [ ! -f "$d1" ] && cp "$src_file" "$d1" 2>/dev/null || true
        if [ -n "$dest2" ]; then
            local d2="$dest2/$rel"
            mkdir -p "$(dirname "$d2")"
            [ ! -f "$d2" ] && cp "$src_file" "$d2" 2>/dev/null || true
        fi
        copied=$((copied+1))
        card_set $c $k cf "$copied"
        [ $((copied % 5)) -eq 0 ] && write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
    done < <(find "$source" -type f -print0)
    local dst_files=$(find "$dest1" -type f | wc -l | tr -d ' ')
    local dst_bytes=$(du -sk "$dest1" | awk '{print $1*1024}')
    card_set $c $k cf "$dst_files"
    card_set $c $k cb "$dst_bytes"
    local fj="[" ff=true
    while IFS= read -r fp; do
        local fn=$(basename "$fp") fsz=$(stat -f%z "$fp" 2>/dev/null || echo 0)
        fn=$(echo "$fn" | sed 's/"/\\"/g')
        $ff || fj+=","; fj+="{\"name\":\"$fn\",\"size\":$fsz}"; ff=false
    done < <(find "$dest1" -type f ! -name ".*" | sort)
    fj+="]"; card_set $c $k files "$fj"
    # Store dest path for Finder button
    local dest_escaped=$(echo "$dest1" | sed 's/"/\\"/g')
    card_set $c $k dest "$dest_escaped"

    # ── EXIF summary ──────────────────────────────────────────────────────────
    local exif_json="{}"
    if command -v exiftool &>/dev/null; then
        card_set $c $k status "reading EXIF"
        write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"

        # Pick first image/video file to get camera info
        local sample_file=$(find "$dest1" -type f \( \
            -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.raw" \
            -o -iname "*.cr2" -o -iname "*.cr3" -o -iname "*.arw" \
            -o -iname "*.nef" -o -iname "*.dng" -o -iname "*.heic" \
            -o -iname "*.mp4" -o -iname "*.mov" -o -iname "*.mts" \
            \) 2>/dev/null | head -1)

        local camera="" lens="" date_range="" gps="" isos="" shutters="" apertures=""

        if [ -n "$sample_file" ]; then
            camera=$(exiftool -s3 -Make -Model "$sample_file" 2>/dev/null | tr '\n' ' ' | sed 's/  */ /g;s/ $//')
            lens=$(exiftool -s3 -LensModel "$sample_file" 2>/dev/null | head -1)
        fi

        # Collect ISO, shutter, aperture from all files (most common value)
        isos=$(exiftool -s3 -ISO -ext jpg -ext cr2 -ext cr3 -ext arw -ext nef -ext dng -ext heic "$dest1" 2>/dev/null | sort | uniq -c | sort -rn | head -1 | awk '{print $2}')
        shutters=$(exiftool -s3 -ShutterSpeedValue -ext jpg -ext cr2 -ext cr3 -ext arw -ext nef -ext dng -ext heic "$dest1" 2>/dev/null | sort | uniq -c | sort -rn | head -1 | awk '{print $2}')
        apertures=$(exiftool -s3 -FNumber -ext jpg -ext cr2 -ext cr3 -ext arw -ext nef -ext dng -ext heic "$dest1" 2>/dev/null | sort | uniq -c | sort -rn | head -1 | awk '{print $2}')

        # Date range — first and last file dates
        local first_date=$(exiftool -s3 -DateTimeOriginal "$dest1" 2>/dev/null | sort | head -1 | cut -c1-10 | tr ':' '.')
        local last_date=$(exiftool  -s3 -DateTimeOriginal "$dest1" 2>/dev/null | sort | tail -1 | cut -c1-10 | tr ':' '.')
        [ "$first_date" = "$last_date" ] && date_range="$first_date" || date_range="$first_date – $last_date"

        # GPS — first file with coords
        local gps_raw=$(exiftool -s3 -GPSLatitude -GPSLongitude "$dest1" 2>/dev/null | head -2 | tr '\n' ',')
        [ -n "$gps_raw" ] && gps=$(echo "$gps_raw" | sed 's/,$//')

        # Escape for JSON
        camera=$(echo "$camera"   | sed 's/"/\\"/g')
        lens=$(echo "$lens"       | sed 's/"/\\"/g')
        gps=$(echo "$gps"         | sed 's/"/\\"/g')
        date_range=$(echo "$date_range" | sed 's/"/\\"/g')

        exif_json="{\"camera\":\"$camera\",\"lens\":\"$lens\",\"iso\":\"$isos\",\"shutter\":\"$shutters\",\"aperture\":\"$apertures\",\"dates\":\"$date_range\",\"gps\":\"$gps\"}"
    fi
    card_set $c $k exif "$exif_json"
    local cs_ok=true cs_status="skipped"
    if $DO_CHECKSUM; then
        card_set $c $k status "verifying"
        write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
        while IFS= read -r -d '' sf; do
            local rel="${sf#$source/}" m1=$(md5 -q "$sf" 2>/dev/null)
            local df1="$dest1/$rel"
            if [ -f "$df1" ]; then [ "$(md5 -q "$df1" 2>/dev/null)" != "$m1" ] && cs_ok=false; else cs_ok=false; fi
            if [ -n "$dest2" ]; then
                local df2="$dest2/$rel"
                if [ -f "$df2" ]; then [ "$(md5 -q "$df2" 2>/dev/null)" != "$m1" ] && cs_ok=false; else cs_ok=false; fi
            fi
        done < <(find "$source" -type f -print0)
        $cs_ok && cs_status="ok" || cs_status="failed"
    fi
    local final="ok"
    [ "$src_files" != "$dst_files" ] && final="warning" && ALL_OK=false
    ! $cs_ok && final="warning" && ALL_OK=false
    card_set $c $k status "$final"
    card_set $c $k cs "$cs_status"
    write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
    local src_mb=$(echo "scale=1; $src_bytes/1048576" | bc 2>/dev/null || echo "?")
    SUMMARY="$SUMMARY\nCam-$c / $CARDDATE-Card-$k  |  $src_files files  |  ${src_mb} MB  |  Checksum: $cs_status  |  $final"
}

finish() {
    LOGFILE="$LOC1/$PROJECT/${PROJECT}_import_log.txt"
    { echo "=== Import & Backup Log ==="; echo "Project: $PROJECT"; echo "Date: $(date)";
      echo "Import: $LOC1/$PROJECT"; echo "Backup: $LOC2_INFO"; echo "";
      printf "$SUMMARY"; echo "";
      echo "Result: $($ALL_OK && echo 'ALL OK' || echo 'CHECK MANUALLY')"; } >> "$LOGFILE"
    osascript -e "display notification \"Log saved to project folder\" with title \"$TITLE\""
    osascript -e "display dialog \"$($ALL_OK && echo 'All files copied and verified!' || echo 'Done — some items need manual check.')\n\nLog: $LOGFILE\" with title \"$TITLE\" buttons {\"OK\"} default button \"OK\""

    # ── Send email notification ───────────────────────────────────────────────
    if [ -n "$GMAIL_FROM" ] && [ "$GMAIL_FROM" != "yourname@gmail.com" ] && [ -n "$GMAIL_APP_PASSWORD" ]; then
        RESULT_TEXT=$($ALL_OK && echo "All files copied and verified!" || echo "Done — check log for warnings.")
        TOTAL_FILES=$(printf "$SUMMARY" | grep -c "Card-" || echo "?")
        SUBJECT="Import & Backup complete — $PROJECT"
        BODY="Project: $PROJECT
Date: $(date)
Result: $RESULT_TEXT

Import: $LOC1/$PROJECT
Backup: $LOC2_INFO

$SUMMARY"
        # Send via curl + Gmail SMTP
        curl --silent \
            --url "smtps://smtp.gmail.com:465" \
            --ssl-reqd \
            --user "$GMAIL_FROM:$GMAIL_APP_PASSWORD" \
            --mail-from "$GMAIL_FROM" \
            --mail-rcpt "$NOTIFY_TO" \
            --upload-file - << MAILEOF 2>/dev/null
From: Import & Backup <$GMAIL_FROM>
To: $NOTIFY_TO
Subject: $SUBJECT
Content-Type: text/plain; charset=utf-8

$BODY
MAILEOF
        if [ $? -eq 0 ]; then
            osascript -e "display notification \"Notification sent to $NOTIFY_TO\" with title \"$TITLE\""
        else
            osascript -e "display notification \"Could not send email — check config file\" with title \"$TITLE\""
        fi
    fi

    rm -f /tmp/fotograf_*
}

# ── Mode selector ─────────────────────────────────────────────────────────────
MODE=$(osascript -e "display dialog \"What do you want to do?\" with title \"$TITLE\" buttons {\"Cancel\", \"Add to existing project\", \"New project\"} default button \"New project\"")
[ $? -ne 0 ] && exit 0
MODECHOICE=$(echo "$MODE" | grep -o 'button returned:[^,]*' | sed 's/button returned://' | tr -d ' ')

if [ "$MODECHOICE" = "Addtoexistingproject" ]; then

    # ── Pick existing project folder ──────────────────────────────────────────
    osascript -e "display dialog \"Select your existing project folder.\" with title \"$TITLE\" buttons {\"Cancel\", \"Choose Folder\"} default button \"Choose Folder\""
    [ $? -ne 0 ] && exit 0
    PROJ_FOLDER=$(osascript -e 'tell application "System Events"
    set chosen to choose folder with prompt "Select the existing project folder:"
    return POSIX path of chosen
end tell')
    [ -z "$PROJ_FOLDER" ] && exit 0
    PROJ_FOLDER="${PROJ_FOLDER%/}"
    LOC1="$(dirname "$PROJ_FOLDER")"
    PROJECT="$(basename "$PROJ_FOLDER")"
    HTML_FILE="$LOC1/$PROJECT/Import_Backup.html"

    # Detect structure
    CAMERAS=$(find "$PROJ_FOLDER" -maxdepth 1 -type d -name "Cam-*" | wc -l | tr -d ' ')
    CARDS=$(find "$PROJ_FOLDER/Cam-1" -maxdepth 1 -type d -name "*-Card-*" 2>/dev/null | wc -l | tr -d ' ')
    [ "$CAMERAS" -eq 0 ] && CAMERAS=1
    [ "$CARDS" -eq 0 ] && CARDS=1

    HAS_BACKUP="false"; LOC2=""; LOC2_INFO="None"
    USE2=$(osascript -e "display dialog \"Project: $PROJECT\nDetected: $CAMERAS cameras, $CARDS cards per camera.\n\nDo you also have a backup location to update?\" with title \"$TITLE\" buttons {\"No\", \"Yes, choose backup location\"} default button \"No\"")
    if echo "$USE2" | grep -q "Yes"; then
        LOC2=$(osascript -e 'tell application "System Events"
    set chosen to choose folder with prompt "Select backup location:"
    return POSIX path of chosen
end tell')
        LOC2="${LOC2%/}"; LOC2_INFO="$LOC2"; HAS_BACKUP="true"
    fi

    DO_CHECKSUM=false
    CS_ANSWER=$(osascript -e "display dialog \"Run checksum verification after copying?\" with title \"$TITLE\" buttons {\"Skip checksum\", \"Yes, verify checksums\"} default button \"Yes, verify checksums\"")
    echo "$CS_ANSWER" | grep -q "Yes" && DO_CHECKSUM=true

    rm -f /tmp/fotograf_*
    SUMMARY=""; ALL_OK=true

    # Mark existing cards as "existing" (greyed out in dashboard)
    for ((k=1; k<=CARDS; k++)); do
        for ((c=1; c<=CAMERAS; c++)); do
            card_set $c $k status "existing"; card_set $c $k cs "skipped"
            card_set $c $k sf "0"; card_set $c $k cf "0"
            card_set $c $k sb "0"; card_set $c $k cb "0"; card_set $c $k files "[]"
        done
    done

    # Ask what to add
    ADDMODE=$(osascript -e "display dialog \"Project: $PROJECT\nCurrently: $CAMERAS cameras, $CARDS cards per camera.\n\nWhat do you want to add?\" with title \"$TITLE\" buttons {\"Cancel\", \"Add card to all cameras\", \"Add camera\"} default button \"Add camera\"")
    [ $? -ne 0 ] && exit 0
    ADDCHOICE=$(echo "$ADDMODE" | grep -o 'button returned:[^,]*' | sed 's/button returned://' | tr -d ' ')

    if [ "$ADDCHOICE" = "Addcamera" ]; then
        CAMERAS=$((CAMERAS+1)); NEW_C=$CAMERAS
        for LOC in "$LOC1" ${LOC2:+"$LOC2"}; do
            for ((k=1; k<=CARDS; k++)); do mkdir -p "$LOC/$PROJECT/Cam-$NEW_C/$CARDDATE-Card-$k"; done
        done
        for ((k=1; k<=CARDS; k++)); do
            card_set $NEW_C $k status "waiting"; card_set $NEW_C $k cs "—"
            card_set $NEW_C $k sf "0"; card_set $NEW_C $k cf "0"
            card_set $NEW_C $k sb "0"; card_set $NEW_C $k cb "0"; card_set $NEW_C $k files "[]"
        done
        write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
        open -a Safari "$HTML_FILE"; sleep 1
        for ((k=1; k<=CARDS; k++)); do
            SOURCE=$(osascript -e "tell application \"System Events\"
    set chosen to choose folder with prompt \"Select source for Cam-$NEW_C / $CARDDATE-Card-$k:\"
    return POSIX path of chosen
end tell")
            [ -z "$SOURCE" ] && continue; SOURCE="${SOURCE%/}"
            DEST1="$LOC1/$PROJECT/Cam-$NEW_C/$CARDDATE-Card-$k"
            [ -n "$LOC2" ] && DEST2="$LOC2/$PROJECT/Cam-$NEW_C/$CARDDATE-Card-$k" || DEST2=""
            copy_card $NEW_C $k "$SOURCE" "$DEST1" "$DEST2"
        done

    elif [ "$ADDCHOICE" = "Addcardtoallcameras" ]; then
        CARDS=$((CARDS+1)); NEW_K=$CARDS
        for LOC in "$LOC1" ${LOC2:+"$LOC2"}; do
            for ((c=1; c<=CAMERAS; c++)); do mkdir -p "$LOC/$PROJECT/Cam-$c/$CARDDATE-Card-$NEW_K"; done
        done
        for ((c=1; c<=CAMERAS; c++)); do
            card_set $c $NEW_K status "waiting"; card_set $c $NEW_K cs "—"
            card_set $c $NEW_K sf "0"; card_set $c $NEW_K cf "0"
            card_set $c $NEW_K sb "0"; card_set $c $NEW_K cb "0"; card_set $c $NEW_K files "[]"
        done
        write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
        open -a Safari "$HTML_FILE"; sleep 1
        for ((c=1; c<=CAMERAS; c++)); do
            SOURCE=$(osascript -e "tell application \"System Events\"
    set chosen to choose folder with prompt \"Select source for Cam-$c / $CARDDATE-Card-$NEW_K:\"
    return POSIX path of chosen
end tell")
            [ -z "$SOURCE" ] && continue; SOURCE="${SOURCE%/}"
            DEST1="$LOC1/$PROJECT/Cam-$c/$CARDDATE-Card-$NEW_K"
            [ -n "$LOC2" ] && DEST2="$LOC2/$PROJECT/Cam-$c/$CARDDATE-Card-$NEW_K" || DEST2=""
            copy_card $c $NEW_K "$SOURCE" "$DEST1" "$DEST2"
        done
    fi

    finish; exit 0
fi

# ── New project ───────────────────────────────────────────────────────────────
PROJECT=$(osascript -e "tell application \"System Events\"
    set answer to text returned of (display dialog \"Project name:\" default answer \"$TODAY\" with title \"$TITLE\" buttons {\"Cancel\", \"Next\"} default button \"Next\")
end tell")
[ $? -ne 0 ] && exit 0; [ -z "$PROJECT" ] && exit 0

CAMERAS=$(osascript -e "tell application \"System Events\"
    set answer to text returned of (display dialog \"How many cameras?\" default answer \"2\" with title \"$TITLE\" buttons {\"Cancel\", \"Next\"} default button \"Next\")
end tell")
[ $? -ne 0 ] && exit 0
[[ ! "$CAMERAS" =~ ^[0-9]+$ ]] && osascript -e "display alert \"Please enter a number.\" as warning" && exit 1

CARDS=$(osascript -e "tell application \"System Events\"
    set answer to text returned of (display dialog \"How many memory cards per camera?\" default answer \"2\" with title \"$TITLE\" buttons {\"Cancel\", \"Next\"} default button \"Next\")
end tell")
[ $? -ne 0 ] && exit 0
[[ ! "$CARDS" =~ ^[0-9]+$ ]] && osascript -e "display alert \"Please enter a number.\" as warning" && exit 1

osascript -e "display dialog \"Choose the import folder location.\" with title \"$TITLE\" buttons {\"Cancel\", \"Choose Folder\"} default button \"Choose Folder\""
[ $? -ne 0 ] && exit 0
LOC1=$(osascript -e 'tell application "System Events"
    set chosen to choose folder with prompt "Select import location:"
    return POSIX path of chosen
end tell')
[ -z "$LOC1" ] && exit 0; LOC1="${LOC1%/}"

USE2=$(osascript -e "display dialog \"Do you want to save to a second location for backup?\" with title \"$TITLE\" buttons {\"No, import only\", \"Yes, choose backup location\"} default button \"Yes, choose backup location\"")
if echo "$USE2" | grep -q "Yes"; then
    LOC2=$(osascript -e 'tell application "System Events"
    set chosen to choose folder with prompt "Select backup location:"
    return POSIX path of chosen
end tell')
    LOC2="${LOC2%/}"; LOC2_INFO="$LOC2"; HAS_BACKUP="true"
else
    LOC2=""; LOC2_INFO="None"; HAS_BACKUP="false"
fi

for LOC in "$LOC1" ${LOC2:+"$LOC2"}; do
    for ((c=1; c<=CAMERAS; c++)); do
        for ((k=1; k<=CARDS; k++)); do
            mkdir -p "$LOC/$PROJECT/Cam-$c/$CARDDATE-Card-$k"
        done
    done
done
HTML_FILE="$LOC1/$PROJECT/Import_Backup.html"

DO_COPY=$(osascript -e "display dialog \"Folders created.\n\nImport: $LOC1/$PROJECT\nBackup: $LOC2_INFO\n\nDo you want to copy files from your memory cards now?\" with title \"$TITLE\" buttons {\"Skip\", \"Yes, copy files\"} default button \"Yes, copy files\"")
if ! echo "$DO_COPY" | grep -q "Yes"; then
    osascript -e "display dialog \"Done! Folders are ready.\" with title \"$TITLE\" buttons {\"OK\"} default button \"OK\""
    exit 0
fi

DO_CHECKSUM=false
CS_ANSWER=$(osascript -e "display dialog \"Run checksum verification after copying?\n\nRecommended but slower for large cards.\" with title \"$TITLE\" buttons {\"Skip checksum\", \"Yes, verify checksums\"} default button \"Yes, verify checksums\"")
echo "$CS_ANSWER" | grep -q "Yes" && DO_CHECKSUM=true

rm -f /tmp/fotograf_*
for ((k=1; k<=CARDS; k++)); do
    for ((c=1; c<=CAMERAS; c++)); do
        card_set $c $k status "waiting"; card_set $c $k cs "—"
        card_set $c $k sf "0"; card_set $c $k cf "0"
        card_set $c $k sb "0"; card_set $c $k cb "0"; card_set $c $k files "[]"
    done
done
write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
open -a Safari "$HTML_FILE"
sleep 1

SUMMARY=""; ALL_OK=true
for ((k=1; k<=CARDS; k++)); do
    for ((c=1; c<=CAMERAS; c++)); do
        SOURCE=$(osascript -e "tell application \"System Events\"
    set chosen to choose folder with prompt \"Select source for Cam-$c / $CARDDATE-Card-$k:\"
    return POSIX path of chosen
end tell")
        [ -z "$SOURCE" ] && continue; SOURCE="${SOURCE%/}"
        DEST1="$LOC1/$PROJECT/Cam-$c/$CARDDATE-Card-$k"
        [ -n "$LOC2" ] && DEST2="$LOC2/$PROJECT/Cam-$c/$CARDDATE-Card-$k" || DEST2=""
        copy_card $c $k "$SOURCE" "$DEST1" "$DEST2"
    done
done

while true; do
    ADD=$(osascript -e "display dialog \"All cards copied!\n\nDo you want to add more cameras or cards to this project?\" with title \"$TITLE\" buttons {\"No, finish\", \"Add camera\", \"Add card\"} default button \"No, finish\"")
    CHOICE=$(echo "$ADD" | grep -o 'button returned:[^,]*' | sed 's/button returned://' | tr -d ' ')
    if [ "$CHOICE" = "Addcamera" ]; then
        CAMERAS=$((CAMERAS+1)); NEW_C=$CAMERAS
        for LOC in "$LOC1" ${LOC2:+"$LOC2"}; do
            for ((k=1; k<=CARDS; k++)); do mkdir -p "$LOC/$PROJECT/Cam-$NEW_C/$CARDDATE-Card-$k"; done
        done
        for ((k=1; k<=CARDS; k++)); do
            card_set $NEW_C $k status "waiting"; card_set $NEW_C $k cs "—"
            card_set $NEW_C $k sf "0"; card_set $NEW_C $k cf "0"
            card_set $NEW_C $k sb "0"; card_set $NEW_C $k cb "0"; card_set $NEW_C $k files "[]"
        done
        write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
        for ((k=1; k<=CARDS; k++)); do
            SOURCE=$(osascript -e "tell application \"System Events\"
    set chosen to choose folder with prompt \"Select source for Cam-$NEW_C / $CARDDATE-Card-$k:\"
    return POSIX path of chosen
end tell")
            [ -z "$SOURCE" ] && continue; SOURCE="${SOURCE%/}"
            DEST1="$LOC1/$PROJECT/Cam-$NEW_C/$CARDDATE-Card-$k"
            [ -n "$LOC2" ] && DEST2="$LOC2/$PROJECT/Cam-$NEW_C/$CARDDATE-Card-$k" || DEST2=""
            copy_card $NEW_C $k "$SOURCE" "$DEST1" "$DEST2"
        done
    elif [ "$CHOICE" = "Addcard" ]; then
        CARDS=$((CARDS+1)); NEW_K=$CARDS
        for LOC in "$LOC1" ${LOC2:+"$LOC2"}; do
            for ((c=1; c<=CAMERAS; c++)); do mkdir -p "$LOC/$PROJECT/Cam-$c/$CARDDATE-Card-$NEW_K"; done
        done
        for ((c=1; c<=CAMERAS; c++)); do
            card_set $c $NEW_K status "waiting"; card_set $c $NEW_K cs "—"
            card_set $c $NEW_K sf "0"; card_set $c $NEW_K cf "0"
            card_set $c $NEW_K sb "0"; card_set $c $NEW_K cb "0"; card_set $c $NEW_K files "[]"
        done
        write_html "$(build_json "$PROJECT" "$CAMERAS" "$CARDS" "—" "$HAS_BACKUP")"
        for ((c=1; c<=CAMERAS; c++)); do
            SOURCE=$(osascript -e "tell application \"System Events\"
    set chosen to choose folder with prompt \"Select source for Cam-$c / $CARDDATE-Card-$NEW_K:\"
    return POSIX path of chosen
end tell")
            [ -z "$SOURCE" ] && continue; SOURCE="${SOURCE%/}"
            DEST1="$LOC1/$PROJECT/Cam-$c/$CARDDATE-Card-$NEW_K"
            [ -n "$LOC2" ] && DEST2="$LOC2/$PROJECT/Cam-$c/$CARDDATE-Card-$NEW_K" || DEST2=""
            copy_card $c $NEW_K "$SOURCE" "$DEST1" "$DEST2"
        done
    else
        break
    fi
done

finish
